const db = require('../lib/db');
const core = require('../lib/core');

module.exports = async (req, res) => {
  const pw = req.headers['x-admin-password'] || '';
  if (!process.env.ADMIN_PASSWORD || !core.safeEq(pw, process.env.ADMIN_PASSWORD)) return res.status(401).json({ error: 'Unauthorized' });
  try {
    if (req.method === 'POST' && req.query.action === 'confirm') {
      const o = await core.markPaidAndProvision(String(req.query.id || ''), ['pending', 'paid_error', 'amount_mismatch', 'payment_expired']);
      return o ? res.status(200).json(o) : res.status(404).json({ error: 'Not found' });
    }
    res.status(200).json(await db.listOrders());
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
