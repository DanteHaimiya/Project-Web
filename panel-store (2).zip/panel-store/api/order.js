const db = require('../lib/db');
const core = require('../lib/core');
const E = process.env;

module.exports = async (req, res) => {
  try {
    // ---- buat order ----
    if (req.method === 'POST') {
      const b = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
      const { username, email, planId } = b;
      const plan = core.plans.find((p) => p.id === planId);
      if (!plan) return res.status(400).json({ error: 'Paket tidak valid' });
      if (!/^[a-zA-Z0-9_]{3,20}$/.test(username || '')) return res.status(400).json({ error: 'Username 3-20 karakter (huruf/angka/_)' });
      if (!/^\S+@\S+\.\S+$/.test(email || '')) return res.status(400).json({ error: 'Email tidak valid' });

      const id = 'INV' + Date.now().toString(36).toUpperCase();
      const params = { amount: String(plan.price), description: `Order ${id} - ${plan.name}`, fee_by: E.BUATQRIS_FEE_BY || 'user' };
      if (E.BUATQRIS_METHOD) params.qris_method = E.BUATQRIS_METHOD;
      if (core.isTest()) params.test = '1';
      const q = await core.qris('api_create_qris', params);

      await db.createOrder({
        id, username, email, planId,
        amount: plan.price,
        totalAmount: q.total_amount,   // yang HARUS dibayar pembeli (termasuk kode unik)
        transactionId: q.transaction_id,
        qrUrl: q.qr_url,
        paymentUrl: q.payment_url,
        qrisExpiredAt: q.expired_at,
        isTest: core.isTest(),
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      return res.status(200).json({ id });
    }

    // ---- cek status order ----
    if (req.method === 'GET') {
      let o = await db.getOrder(String(req.query.id || ''));
      if (!o) return res.status(404).json({ error: 'Order tidak ditemukan' });

      // cadangan kalau webhook telat: cek ke BuatQris maks 1x / 20 detik
      if (o.status === 'pending' && Date.now() - (o.lastCheck || 0) > 21000) {
        o.lastCheck = Date.now();
        await db.saveOrder(o);
        try {
          const s = await core.qris('api_check_status', { transaction_id: o.transactionId });
          if (s.status === 'success' && Number(s.total_amount) === o.totalAmount) await core.markPaidAndProvision(o.id);
          else if (s.status === 'expired' || s.status === 'failed') {
            const cur = await db.getOrder(o.id);
            if (cur.status === 'pending') { cur.status = 'payment_' + s.status; await db.saveOrder(cur); }
          }
        } catch (e) { /* abaikan, coba lagi nanti */ }
        o = await db.getOrder(o.id);
      }

      const out = { id: o.id, status: o.status, planId: o.planId };
      if (o.status === 'pending') Object.assign(out, { totalAmount: o.totalAmount, qrUrl: o.qrUrl, paymentUrl: o.paymentUrl, expiredAt: o.qrisExpiredAt, isTest: o.isTest });
      if (o.status === 'active') Object.assign(out, { username: o.username, password: o.password, panelUrl: o.panelUrl, expiresAt: o.expiresAt });
      return res.status(200).json(out);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (e) {
    console.error('order:', e.message);
    res.status(502).json({ error: e.message });
  }
};
