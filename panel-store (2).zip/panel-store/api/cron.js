// Dipanggil Vercel Cron: suspend server yang masa aktifnya habis.
const db = require('../lib/db');
const core = require('../lib/core');

module.exports = async (req, res) => {
  const secret = process.env.CRON_SECRET;
  if (secret && req.headers.authorization !== `Bearer ${secret}`) return res.status(401).end();
  let n = 0;
  for (const o of await db.listOrders(1000)) {
    if (o.status === 'active' && new Date(o.expiresAt) < new Date()) {
      try {
        await core.ptero('POST', `/servers/${o.serverId}/suspend`);
        o.status = 'expired';
        await db.saveOrder(o);
        n++;
      } catch (e) { console.error('suspend', o.id, e.message); }
    }
  }
  res.status(200).json({ suspended: n });
};
