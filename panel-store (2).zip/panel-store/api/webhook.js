const crypto = require('crypto');
const { waitUntil } = require('@vercel/functions');
const db = require('../lib/db');
const core = require('../lib/core');
const E = process.env;

const readRaw = (req) =>
  new Promise((resolve, reject) => {
    const c = [];
    req.on('data', (d) => c.push(d));
    req.on('end', () => resolve(Buffer.concat(c)));
    req.on('error', reject);
  });

async function handle(d) {
  if (d.is_test && !core.isTest()) return;           // abaikan sandbox saat mode live
  const o = await db.getOrderByTx(d.transaction_id);
  if (!o) return;
  if (d.event === 'payment.success') {
    if (Number(d.total_amount) !== o.totalAmount) {
      if (o.status === 'pending') { o.status = 'amount_mismatch'; await db.saveOrder(o); }
      return;
    }
    await core.markPaidAndProvision(o.id);           // idempoten
  } else if ((d.event === 'payment.expired' || d.event === 'payment.failed') && o.status === 'pending') {
    o.status = d.event === 'payment.expired' ? 'payment_expired' : 'payment_failed';
    await db.saveOrder(o);
  }
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).end();
  if (!E.BUATQRIS_SIGNING_SECRET) return res.status(500).end();

  const raw = await readRaw(req);
  const sig = String(req.headers['x-buatqris-signature'] || '');
  const calc = 'sha256=' + crypto.createHmac('sha256', E.BUATQRIS_SIGNING_SECRET).update(raw).digest('hex');
  if (calc.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(calc), Buffer.from(sig))) return res.status(401).end();

  let d;
  try { d = JSON.parse(raw.toString('utf8')); } catch { return res.status(400).end(); }

  // balas cepat (batas BuatQris 6 detik), pembuatan panel lanjut di belakang
  waitUntil(handle(d).catch((e) => console.error('webhook:', e.message)));
  res.status(200).end();
};
