# Panel Store (Vercel + Pterodactyl + BuatQris)
Deploy:
1. Upload folder ini ke GitHub, lalu Vercel > Add New > Project > Import. Framework: Other.
2. Vercel > Storage > tambah Upstash Redis, hubungkan ke project (env KV_REST_API_* otomatis terisi).
3. Settings > Environment Variables: isi semua dari .env.example.
4. Settings > Domains: tambah panel.auradante.my.id, lalu di DNS buat CNAME `panel` -> cname.vercel-dns.com
5. Dasbor BuatQris > Open API > Webhook: https://panel.auradante.my.id/api/webhook
6. Tes dengan BUATQRIS_TEST=1, kalau sukses ubah ke 0 lalu Redeploy.
Admin: /admin.html
